import * as data from "../../fixtures/datasource/users.json";
import { faker } from '@faker-js/faker';

class HomePage {
    
    definirLayout() {
        cy.viewport(1440, 900)
    }
    
    abrirPaginaPrincipal() {
        cy.visit('https://seubarriga.wcaquino.me/login')
        cy.wait(2000)
    }

    acessarAreaLogin() {
        cy.get('.active > a').click()
        cy.wait(2000)
    }

    acessarAreaCadastro() {
        cy.get(':nth-child(2) > a').click()
        cy.wait(2000) 
    }

    inserirDadosAcesso() {
        cy.get('#email').type(data.users.usuario)
        cy.get('#senha').type(data.users.senha) 
        cy.wait(2000)       
    }

    clickLogin() {
        cy.get('.btn').click()
        cy.wait(2000) 
    }

    confirmarLogin() {
        cy.contains('Bem vindo, Matheus!')
        cy.wait(2000) 
    }

    inserirDadosCadastrais() {
        cy.get('#nome').type(data.users.nome)
        cy.get('#email').type(faker.internet.email())
        cy.get('#senha').type('TesteTestinha')
        cy.wait(2000) 
    }

    clickCadastro() {
        cy.get('.btn').click()
        cy.wait(2000) 
    }

    confirmaCadastro() {
        cy.contains('Usuário inserido com sucesso')
        cy.wait(2000) 
    }

    login() {
        this.definirLayout()
        this.abrirPaginaPrincipal()
        this.inserirDadosAcesso()
        this.clickLogin()
        this.confirmarLogin()
    }

    abrirPaginaAdicao() {
        cy.get('.caret').click()
        cy.get('.dropdown-menu > :nth-child(1) > a').click()
        cy.wait(2000) 
        cy.contains('Nome')
    }

    abrirPaginaLista() {
        cy.get('.caret').click()
        cy.contains('Listar').click()
        cy.wait(2000) 
        cy.contains('Conta')
    }

    inserirNovaConta() {
        var novaConta = faker.name.firstName()
        cy.get('#nome').type(novaConta)
        cy.get('.btn').click()
        cy.wait(2000) 
    }

    confirmarNovaConta(novaConta) {
        cy.contains(novaConta)
    }

    excluirConta() {
        this.abrirPaginaLista()
        cy.get('span.glyphicon.glyphicon-remove-circle').click()    
    }

    confirmarExclusao() {
        cy.contains('Conta removida com sucesso!')
    }

}

export default HomePage;